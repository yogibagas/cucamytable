<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Point_log extends Model
{
    //
    protected $fillable = ['id_user','points','desc'];
}
