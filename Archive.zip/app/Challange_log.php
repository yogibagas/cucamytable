<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Challange_log extends Model
{
    //
    protected $fillable = ['id_challange','id_user','notification_status'];
}
