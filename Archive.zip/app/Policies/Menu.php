<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class Menu
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
    }


    public function view(User $user)
    {
      //choose role that return true to access
      //in this case only role with 0 can get this authorized
      return $user->role === 0;
    }


}
