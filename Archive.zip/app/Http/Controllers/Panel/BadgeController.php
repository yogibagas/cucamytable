<?php

namespace App\Http\Controllers\Panel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Badge;

class BadgeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = Badge::orderBy('id','desc')->paginate(10);
        return view('panel.badge')
        ->with('data',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $model = new Badge();
        return view('panel.form.badge')->with('data',$model);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $validation = $request->validate([
            'name' => 'required|string|max:125',
            'badge_image' => 'image|mimes:png|max:1024',
        ]);
        
        if($request->badge_image != null){
            $filename = pathinfo($request->badge_image->getClientOriginalName(), PATHINFO_FILENAME);
            $imageName = $filename . '-' . time() . '.' . $request->badge_image->extension();
        }else{
            $imageName = "";
        }

        try {
            $request->badge_image->move(public_path('images/badges'), $imageName);
            $data = [
                'name' => $request->name,
                'image'=> $imageName,
                'status' => $request->status,
            ];
            Badge::create($data);

            return back()
                ->with('success', 'You have successfully add the new badge.');
        } catch(\Exception $ex) {
            return back()->with('failed', 'Error! ' . $ex->getMessage());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $model = Badge::findOrFail($id);
        return view('panel.form.badge')->with('data',$model);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $model = Badge::findOrFail($id);
        $validation = $request->validate([
            'name' => 'required|string|max:125',
            'badge_image' => 'nullable|image|mimes:png|max:1024',
        ]);

        if($request->badge_image != null){
            $filename = pathinfo($request->badge_image->getClientOriginalName(), PATHINFO_FILENAME);
            $imageName = $filename . '-' . time() . '.' . $request->badge_image->extension();
            $request->badge_image->move(public_path('images/badges'), $imageName);
        }else{
            $imageName = $model->image;
        }

        try {
            $data = [
                'name' => $request->name,
                'image'=> $imageName,
                'status' => $request->status,
            ];
            $model->update($data);

            return back()
                ->with('success', 'You have successfully update the badge.');
        } catch(\Exception $ex) {
            return back()->with('failed', 'Error! ' . $ex->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
