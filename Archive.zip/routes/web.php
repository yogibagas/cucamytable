<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('front-site/index');
});


Route::resource('country','CountryController');



Auth::routes();

Route::group(['prefix' => 'panel', 'middleware' => ['admin']], function () {
    Route::group(['middleware' => 'auth:web'],function(){


        Route::get('/', 'Panel\PanelController@index')->name('dashboard');

        Route::resource('/badge','Panel\BadgeController');

        Route::get('/profile', 'Panel\ProfileController@index')->name('profile');
        Route::resource('/menu','Panel\MenuController');
        Route::get('/menu','Panel\MenuController@index')->name('menu');
        Route::get('/menu/{id}/delete','Panel\MenuController@delete')->name('menu.delete');


        Route::resource('/space','Panel\SpaceController');
        Route::get('/space/{id}/delete','Panel\SpaceController@delete')->name('space.delete');

        Route::GET('/reservation/list','Panel\ReservationController@reservationList')->name('reservation.list');
        Route::GET('/reservation/{reservation}/summary','Panel\ReservationController@show')->name('reservation.summary');
        Route::resource('/reservation', 'Panel\ReservationController');
        Route::post('/reservation/cekstep1','Panel\ReservationController@step1Form')->name('reservation.step1');
        Route::post('/reservation/menu-check','Panel\ReservationController@stepMenu')->name('reservation.menucheck');
        Route::post('/reservation/revieworder','Panel\ReservationController@reviewOrder')->name('reservation.revieworder');
        Route::post('/reservation/getwords','Panel\ReservationController@getWords')->name('reservation.getwords');
        Route::post('/reservation/payment','Panel\ReservationController@beforepayment')->name('reservation.payment');
        Route::post('/reservation/notify','Panel\ReservationController@notify')->name('reservation.notify');

        Route::resource('/reward','Panel\RewardController');
        Route::get('/reward/rewardlist/{type}','Panel\RewardController@rewardList')->name('reward.list');

        Route::resource('/challange','Panel\ChallangeController');

    });
});
