
      <!-- Footer -->
      
    </div>
  </div>
  <!--   Core   -->
  <script src="<?php echo e(url('/assets/js/plugins/jquery/dist/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
  <!--   Optional JS   -->
  <script src="<?php echo e(url('/assets/js/plugins/chart.js/dist/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/js/plugins/chart.js/dist/Chart.extension.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/js/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script src="<?php echo e(url('/js/jquery.datetimepicker.full.js')); ?>"></script>
  <!--   Argon JS   -->
  <script src="<?php echo e(url('/assets/js/argon-dashboard.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/js/timepicker.min.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/js/moment.js')); ?>"></script>
  
  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH /Users/yogibagasd/Documents/skripsi/project/cuca-table/resources/views/panel/components/footer.blade.php ENDPATH**/ ?>