<?php $__env->startSection('page_name'); ?> Your Reservation Summary <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_link'); ?> <?php echo e(route('reservation.index')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('reservation.payment')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<div class="container">
						<div class="row pt-3">
							<div class="col">
							<div class="col-md-12 p-0">
								<div class="row bg-plain-white" style="border:1px solid #a5783f;" >
									<div class="col-md-12 header p-0 bg-plain-white">
										<img src="<?php echo e(url('/images/reservation/header.png')); ?>" class="img-fluid">
									</div>
									<div class="col-md-12 p-0 m-0">
										<?php if($reservation->payment_status == -2): ?>
												<center><h4 class="m-0" style="background:red;color:#FFF;padding-top:15px;padding-bottom:15px;"><?php echo e("This Reservation Has Been Canceled"); ?></h4></center>
										<?php elseif($reservation->payment_status == -1): ?>
										<center><h4 class="m-0" style="background:blue;color:#FFF;padding-top:15px;padding-bottom:15px;"><?php echo e("Please Complete Your Payment Before"); ?>

											<?php echo e($expired_date); ?></h4></center>
										<?php elseif($reservation->payment_status == 0): ?>
												<center><h4 class="m-0" style="background:orange;color:#FFF;padding-top:15px;padding-bottom:15px;">We are Ready To Serve You!<br>
													Your Reservation Time is <b><u><?php echo e($reservation->reservation_datetime); ?></b></u></h4></center>
									 <?php elseif($reservation->payment_status == 1): ?>
												<center><h4 class="m-0" style="background:brown;color:#FFF;padding-top:15px;padding-bottom:15px;"> You did not show up on your reservation time!<br>
													 Your reservation was made for <b><u><?php echo e(\Carbon\Carbon::parse($reservation->reservation_datetime)->format('d F Y H:i')); ?></b></u></h4></center>
										<?php endif; ?>
									</div>
									<div class="col-12 text-center bg-plain-white pt-3 pb-3 border-bottom">
										<h4>
											Reservation made for <b><?php echo e(Auth::user()->name); ?></b><br>
											<?php if($reservation->payment_status == 0): ?>
											Please provide reservation code below when come to Cuca to Confirm your Reservation</br>
											Reservation Code : <b><?php echo e($reservation->reservation_code); ?> </b>
											<?php endif; ?>
										</h4>
									</div>
										<div class="table table-responsive">
											<table class="table table-bordered bg-plain-white m-0">
												<thead>
                          <tr>
													<th colspan="2 p-3">

                          </th>
                        </tr>
												</thead>
                      </table>
                      <table class="table table-striped bg-plain-white m-0">
												<tbody>
													<tr>
														<td>Date : </td>
                            <td class="text-bold" id="date_value">
															<INPUT TYPE="text" readonly="" class="p-0 bg-none border-0 text-bold" value="<?php echo e(\Carbon\Carbon::parse($reservation->reservation_datetime)->format('d-m-Y')); ?>">
																</td>
														<td>Time : </td>
                            <td class="text-bold" id="time_value">
															<INPUT TYPE="text" readonly="" class="p-0 bg-none border-0 text-bold" value="<?php echo e(\Carbon\Carbon::parse($reservation->reservation_datetime)->format('H:i')); ?>">
														</td>
													</tr>
                          <tr>
                            <td>Pax :</td>
                            <td class="text-bold" id="pax_value">
															<INPUT TYPE="text" readonly="" class="p-0 bg-none border-0 text-bold" value="<?php echo e($reservation->total_pax); ?>">
															</td>
                            <td>Space :</td>
                            <td class="text-bold" id="space_value">
															<INPUT TYPE="text" readonly="" class="p-0 bg-none border-0 text-bold" value="<?php echo e($reservation->space->name); ?>">
														</td>
                          </tr>
                          <tr>
                            <td colspan="4"><b>Special Notes :</b><br>
															<?php echo e($reservation->special_notes); ?>


														</td>
													</tr>
												</tbody>
											</table>
                      <table class="table table-bordered bg-plain-white m-0">
                        <thead>
                          <tr>
                          <th colspan="6" class="text-center">
															<strong><h4>Picked Menu</h4></strong>
                          </th>
                        </tr>
                        <tr>
                          <th colspan="3" class="text-center text-bold"><h5>Menu Name</h5></th>
                          <th colspan="1" class="text-center text-bold"><h5>Quantity</h5></th>
                          <th colspan="1" class="text-center text-bold"><h5>Price /Qty </h5></th>
                          <th colspan="1" class="text-center text-bold"><h5>Total </h5></th>
                        </tr>
                        </thead>
                        <tbody id="menu-body"><tr>
													<?php $__currentLoopData = $reservation->detailReservation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						                <td colspan="3" style="text-transform:capitalize;"><?php echo e($menu->name); ?><small>(<?php echo e($menu->category->name); ?>)</small></td>
						                <td class="text-center"><?php echo e($menu->pivot->qty); ?></td>
						                <td class="text-right"><?php echo e($menu->price); ?></td>
						                <td class="text-right"><?php echo e($menu->price*$menu->pivot->qty); ?></td>
						                </tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php if($reservation->payment_status == -1): ?>
													<tr>
														<td class="text-center" colspan="6">
															<strong><h4>Payment Breakdown</h4></strong>
														</td>
													</tr>
													<?php endif; ?>
												</tbody>
												<?php if($reservation->payment_status == -1): ?>
                        <tfoot style="background:rgba(0, 0, 0, 0.05);">
                          <tr>
														<td colspan="5" class="text-bold">Sub Total<small>(Food Items)</small> </td>
	                          <td class="text-right text-bold" id="total_value">IDR. <?php echo e(number_format($calculation['subTotal'],0,",",".")); ?></td>
	                        </tr>
                          <tr>
														<td colspan="5" class="text-bold ">Tax<small>(10.8%)</small </td>
	                          <td class="text-right text-bold" id="total_value">IDR. <?php echo e(number_format($calculation['tax'],0,",",".")); ?></td>
	                        </tr>
                          <tr>
														<td colspan="5" class="text-bold ">Services<small>(8%)</small </td>
	                          <td class="text-right text-bold" id="total_value">IDR. <?php echo e(number_format($calculation['service'],0,",",".")); ?></td>
	                        </tr>
                          <tr>
														<td colspan="5" class="text-bold ">Grand Total </td>
	                          <td class="text-right text-bold" id="total_value">IDR. <?php echo e(number_format($calculation['total'],0,",",".")); ?></td>
	                        </tr>
											</tfoot>
											<?php endif; ?>
                      </table>
											<?php if($reservation->payment_status == -1): ?>
                      <table class="table table-bordered bg-plain-white">
                        <thead>
                          <tr>
                          <th colspan="8" class="text-center">
															<strong><h4>Detail Payment</h4></strong><br>
                          </th>
                        </tr>
                        </thead>
                        <tbody>
													<tr>
														<td class="text-bold" colspan="5">Down Payment<small>(50% from Grand Total)</small></td>
														<td class="text-right text-bold">IDR. <input class="bg-none border-0 text-right text-bold" id="dpPrice"></td>
													</tr>
													<tr>
														<td class="text-bold" colspan="5">Point Worth</small></td>
														<td class="text-right text-bold">IDR. <input class="bg-none border-0 text-right text-bold" value="0" name="discount" id="discount"></td>
													</tr>
													<tr>
														<td class="text-bold" colspan="5">Total Pay</small></td>
														<td class="text-right text-bold">IDR. <input class="bg-none border-0 text-right text-bold" value="0" name="total_pays" id="total_pays"></td>
													</tr>
													<?php if($points >0 ): ?>
													<tr>
														<td class="text-bold">
															<label>Use my <?php echo e($points); ?> Points in a payment</label><br>
															<label class="custom-toggle">
															  <input type="checkbox" name="usePoint" id="usePoint">
															  <span class="custom-toggle-slider rounded-circle"></span>
															</label>
														</td>
													</tr>
													<?php endif; ?>
                        </tbody>
                      </table>
											<div class="col-md-12">
												<ul style="list-style-type:circle;">
												<li>
													Belongs to Cuca <a href="#">Terms & Condition</a> , user that make reservation must pay 50% as guarantee not showing up on reservation time and the rest can pay in the restaurant.</div>
												</li>
											</ul>
										</div>
										<?php endif; ?>
									</div>
								</div>
								<input type="HIDDEN" name="ADDITIONALDATA" class="form-control" value=" <?php echo e(Auth::user()->name); ?>;<?php echo e($reservation->total_pax); ?>;<?php echo e($reservation->reservation_datetime); ?>;<?php echo e($reservation->space->name); ?>">
								<input type="HIDDEN" name="GRANDTOTAL" id="grandTotal" class="form-control" value="">
								<input type="HIDDEN" name="NAME" class="form-control" value="<?php echo e($reservation->user->name); ?> ">
								<input type="HIDDEN" name="SESSIONID" class="form-control" value="<?php echo e(md5(uniqid(rand(), true))); ?>">
								<input type="HIDDEN" name="EMAIL" class="form-control" value="<?php echo e($reservation->user->email); ?>">
								<input type="HIDDEN" name="REQUESTDATETIME" class="form-control" value="<?php echo e(date("YmdHis")); ?>">
								<input type="HIDDEN" name="CHAINMERCHANT" class="form-control" value="NA">
								<input type="HIDDEN" name="BASKET" id="basket" class="form-control" value="<?php echo e($basket); ?>">
								<input type="HIDDEN" name="CURRENCY" class="form-control" value="360">
								<input type="HIDDEN" name="PURCHASECURRENCY" class="form-control" value="360">
								<input type="HIDDEN" name="AMOUNT" class="form-control" id="amount" value="">
								<input type="HIDDEN" name="PURCHASEAMOUNT" id="purchaseamount" class="form-control" value="">
								<input type="HIDDEN" name="PAYMENTCHANNEL" id="" class="form-control" value="15">
								<input type="HIDDEN" name="MALLID" class="form-control" value="11787948">
								<input type="HIDDEN" name="TRANSIDMERCHANT" class="form-control" value="<?php echo e($reservation->reservation_code); ?>">
								<input type="HIDDEN" name="WORDS" id="words" class="form-control" value=" <?php echo e(sha1((50/100*$calculation['total']) . '.00' . '11787948' . 'YhaXnBGdXutG' . $reservation->reservation_code)); ?> ">

    							<div class="form-group clearfix">
    								<a href="<?php echo e(route('reservation.index')); ?>" class="btn btn-warning float-left" id="back3">Pay Later</a>
    								<button type="submit" class="btn btn-flat btn-success float-right" style="cursor:pointer">Pay Now</button>
    							</div>
							</div>
						</div>
						</div>
						</div>
<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(e){
	var downPaymentPrice = (50/100) * <?php echo e($calculation['total']); ?>;
	var basket = "<?php echo e($basket); ?>";
	// console.log(downPaymentPrice);
	$("#dpPrice").val((downPaymentPrice/1000).toFixed(3));
		$("#total_pays").val((downPaymentPrice/1000).toFixed(3));
		$("#grandTotal").val(downPaymentPrice+".00");
		$("#amount").val(downPaymentPrice+".00");
		$("#purchaseamount").val(downPaymentPrice+".00");
		var printBasket = basket+";Down Payment,-"+downPaymentPrice+".00"+",1,"+"-"+downPaymentPrice+".00";
		$("#basket").val(printBasket);
	//check point used or not
		var clicking = 1;
	$("#usePoint").on('change',function(){
		var basket = "<?php echo e($basket); ?>";
		var dpPrice = (50/100) * <?php echo e($calculation['total']); ?>;
		var points = <?php echo e($points); ?>;
		var grandTotal = dpPrice;
		if(clicking == 1){
			grandTotal -= points;
			$("#discount").val((points/1000).toFixed(3));
			printBasket += ";Points,-"+points+".00"+",1,"+"-"+points+".00";
		clicking++;
	}else{
		grandTotal = dpPrice;
		$("#discount").val(0);
		printBasket = basket+";Down Payment,-"+downPaymentPrice+".00"+",1,"+"-"+downPaymentPrice+".00";
		clicking--;
	}

	$("#total_pays").val((grandTotal/1000).toFixed(3));
	$("#grandTotal").val(grandTotal+".00");
	$("#amount").val(grandTotal+".00");
	$("#purchaseamount").val(grandTotal+".00");
	$("#basket").val(printBasket);

	// $calculation['total'] . '.00' . '11787948' . 'YhaXnBGdXutG' . $reservation->reservation_code
	var data = {
		"_token":$('meta[name="csrf-token"]').attr('content'),
	 'amount' : grandTotal+".00",
	 'merchantID' : '11787948',
	 'shareKey' : 'YhaXnBGdXutG',
	 'reservationCode' : '<?php echo e($reservation->reservation_code); ?>',
}
	$.ajax({
		data : data,
		method : "POST",
		url:'<?php echo e(route("reservation.getwords")); ?>',
		success(result){
			$("#words").val(result);
		}
	});

		// if($(this).val('on'))
		// 	// alert('checked');
		// 	else {
		// 		// alert('not checked');
		// 	}
	});
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yogibagasd/Documents/skripsi/project/cuca-table/resources/views/panel/reservation/summary.blade.php ENDPATH**/ ?>