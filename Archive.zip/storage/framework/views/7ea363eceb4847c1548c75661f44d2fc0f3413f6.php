<?php $__env->startSection('page_name'); ?> Restaurant Menu <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_link'); ?> <?php echo e(route('menu')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid mt--7">
     
      <div class="row">
        <div class="col">
            <div class="card shadow">
            <div class="card-header border-0">
              <h3 class="mb-0">Form Reward</h3>
            </div>
                <form class="pl-4 pr-4" method="POST" action="<?php echo e($data->exists ? route('reward.update',$data->id) : route('reward.store')); ?>" enctype="multipart/form-data">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="alert alert-danger" role="alert">
                Error! <strong><?php echo e($message); ?></strong> 
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                </button>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e($message); ?>

                </div>
                <?php elseif($message = Session::get('failed')): ?>
                <div class="alert alert-danger">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>
                <?php echo e($data->exists ? method_field('PUT') : method_field('POST')); ?>

                    <?php echo csrf_field(); ?>
                    
                    <div class="row">
                        <div class="col-md-4">
                        <div class="form-group">
                            <label>Point Type<small>(Choose point reward type Flat or %)</small></label>
                            <div class="form-group">
                                <select name="point_type" class="form-control" id="point_type">
                                    <option value="FLAT" <?php echo e($data->point_type == "FLAT" ? "selected" : false); ?>>FLAT POINTS</option>
                                    <option value="PERCENTAGE" <?php echo e($data->point_type == "PERCENTAGE" ? "selected" : false); ?>>PERCENTAGE (%)</option>
                                </select>
                            </div>
                        </div>
                        </div>
                        <div class="col-md-4">
                        <div class="form-group">
                            <label>Point Rewards<small>(use . as a decimal symbol)</small></label>
                            <div class="form-group">
                                <div class="input-group">
                                <input class="form-control" placeholder="How much point user get" type="text" name="point" value="<?php echo e($data->point); ?>">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="point_text" >Points</span>
                                </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        <div class="col-md-4">
                        <div class="form-group">
                            <label>Max Points <small>(Put Maximum points can user get)</small></label>
                            <div class="form-group">
                            <div class="input-group">
                                    <input type="number" placeholder="Maximum points user can get" class="form-control" name="max_point" value="<?php echo e($data->max_point); ?>">
                                    <div class="input-group-prepend">
                                    <span class="input-group-text">Points</span>
                                </div>
                            </div>
                            </div>
                                
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3" id="badge">
                        <input type="checkbox" class="" id="badges" name="badge" <?php echo e($data->id_badge == null ? false:"checked"); ?>>  
                        <label for="badges">This Reward is get a badge</label>
                        </div>
                        <div class="col-md-9" id="badgeReward">
                            <div class="badgeReward" >
                            <label>Choose Badge as a Reward</label>
                            <div class="form-group">
                                <select class="form-control" name="id_badge" id="id_badge">
                                <option value="" <?php echo e($data->id_badge == null ? "selected":false); ?>>-- Select the badge</option>
                                <?php $__currentLoopData = $badge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($b->id); ?>" <?php echo e($data->id_badge == $b->id ? "selected":false); ?>><?php echo e($b->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label>Status</labeL>
                            <div class="custom-control custom-radio mb-3">
                                <input type="radio" name="status" class="" checked value="1" <?php echo e($data->exists && $data->status == 1 ? 'Checked': 'checked'); ?> > Active
                                <input type="radio" name="status" class="ml-2" value="0" <?php echo e($data->exists && $data->status == 0 ? 'Checked': false); ?>> Deactive
                            </div>
                        </div>
                    </div>
                    <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="submit" class="btn btn-success">
                                </div>
                            </div>
                    </div>
                    
                </form>
            </div>   
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        if($("#point_type").val() == "FLAT")
            $("#point_text").html("POINTS");
            else
            $("#point_text").html("%")

        if($("#badges").is(':checked')){
        $("#badgeReward").show();
    }else{
        $("#badgeReward").hide();
        $("#id_badge").val("");
    }

        $("#point_type").on('change',function(){
            if($(this).val() == "FLAT")
            $("#point_text").html("POINTS");
            else
            $("#point_text").html("%")
        });
    });
$(document).ready(function(){
});
$("#badges").click(function(){
    if($(this).is(':checked')){
        $("#badgeReward").show();
    }else{
        $("#badgeReward").hide();
        $("#id_badge").val("");
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('panel.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/project/cuca-table/resources/views/panel/form/reward.blade.php ENDPATH**/ ?>