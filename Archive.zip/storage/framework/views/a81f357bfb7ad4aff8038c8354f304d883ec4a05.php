<?php $__env->startSection('page_name'); ?> Restaurant Menu <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_link'); ?> <?php echo e(route('menu')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid mt--7">
     
      <div class="row">
        <div class="col">
            <div class="card shadow">
            <div class="card-header border-0">
              <h3 class="mb-0">Form Create</h3>
            </div>
                <form class="pl-4 pr-4" method="POST" action="<?php echo e($data->exists ? route('menu.update',$data->id) : route('menu.store')); ?>" enctype="multipart/form-data">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="alert alert-danger" role="alert">
                Error! <strong><?php echo e($message); ?></strong> 
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                </button>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e($message); ?>

                </div>
                <?php elseif($message = Session::get('failed')): ?>
                <div class="alert alert-danger">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>
                <?php echo e($data->exists ? method_field('PUT') : method_field('POST')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <label>Menu Name</label>
                            <div class="form-group">
                                <input type="text" class="form-control" id="name" placeholder="Menu Name" name="name" value="<?php echo e($data->name); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-group">
                            <label>Price <small>(Price are in IDR following the goverment policy)</small></label>
                            <input type="text" id="price" placeholder="Menu Price" class="form-control"  name="price" value="<?php echo e($data->price); ?>"/>
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label>Category</label>
                        <div class="form-group" >
                            <select class="form-control" name="id_category">
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ct->id); ?>" <?php echo e($ct->id == $data->id_category ? "Selected": false); ?>><?php echo e($ct->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        </div>
                        <div class="col-md-3">
                            <label>Status</labeL>
                            <div class="custom-control custom-radio mb-3">
                                <input type="radio" name="status" class="" checked value="1" <?php echo e($data->exists && $data->status == 1 ? 'Checked': 'checked'); ?> >Active
                                <input type="radio" name="status" class="ml-2" value="0" <?php echo e($data->exists && $data->status == 0 ? 'Checked': false); ?>> Deactive
                            </div>
                        </div>
                        
                    </div>

                    <div class="row">
                            <div class="col-md-12">
                                <label>Images<small> <?php echo e($data->exists ? '(Leave it empty if you don\'t want to change the image. Size Allowed : 1Mb)' : '(File allowed : jpeg/jpg/png only no more than 1Mb)'); ?></small></label>
                                <div class="form-group">
                                    <input type="file" class="form-control" name="menu_images">
                                </div>
                            </div>
                    </div>
                    <div class="row">
                            <div class="col-md-12">
                                <label>Description</label>
                                <div class="form-group">
                                <textarea name="desc" class="form-control"></textarea>
                                </div>
                            </div>
                    </div>
                    <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="submit" class="btn btn-success">
                                </div>
                            </div>
                    </div>
                    
                </form>
            </div>   
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/project/cuca-table/resources/views/panel/form/menu.blade.php ENDPATH**/ ?>