
	<!-- login -->
	<div class="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="materialContainer">


	<form method="POST" action="<?php echo e(route('login')); ?>">
<div class="box">
	<?php echo csrf_field(); ?>
   <div class="title">LOGIN</div>

   <div class="input">
	  <label for="name">Username</label>
	  <input type="text" name="username"  class="<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" value="<?php echo e(old('username')); ?>">
	  <span class="spin"></span>
   </div>

   <div class="input">
	  <label for="pass">Password</label>
	  <input type="password" name="pass" class="<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pass" value="<?php echo e(old('username')); ?>">
	  <span class="spin"></span>
   </div>

   <div class="button login">
	  <button type="submit"><span>Login</span> <i class="fa fa-check"></i></button>
   </div>

   <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link pass-forgot" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>

</div>

</form>

<div class="overbox">
   <div class="material-button alt-2"><span class="shape"></span></div>

   <div class="title">REGISTER</div>

   <div class="input">
	  <label for="regname">Username</label>
	  <input type="text" name="regname" id="regname">
	  <span class="spin"></span>
   </div>

   <div class="input">
	  <label for="regpass">Password</label>
	  <input type="password" name="regpass" id="regpass">
	  <span class="spin"></span>
   </div>

   <div class="input">
	  <label for="reregpass">Repeat Password</label>
	  <input type="password" name="reregpass" id="reregpass">
	  <span class="spin"></span>
   </div>

   <div class="button">
	  <button><span>NEXT</span></button>
   </div>


</div>

</div>
	</div>
	<!-- //login -->
	<?php /**PATH /Applications/project/cuca-table/resources/views/front-site/components/login.blade.php ENDPATH**/ ?>