<?php $__env->startSection('page_title'); ?>
Cuca My Table
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

	<div class="news" id="about">
		<div class="container">
			<div class="news-main_wthree_agile">
				<div class="col-md-6 news-left">
					<h2>OUR INTERESTING HISTORY</h2>
				</div>
				<div class="col-md-6 news-right">
					<p>Etiam faucibus viverra libero vel efficitur. Ut semper nisl ut laoreet ultrices. Maecenas dictum arcu purus, sit amet
						volutpat purus viverra sit amet. Quisque lacinia quam sed tortor interdum, malesuada congue nunc ornare. Cum sociis
						natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In semper lorem eget tortor pulvinar ultricies.
					</p>
					<p>Etiam faucibus viverra libero vel efficitur. Ut semper nisl ut laoreet ultrices. Maecenas dictum arcu purus, sit amet
						volutpat purus viverra sit amet. Quisque lacinia quam sed tortor interdum, malesuada congue nunc ornare. Cum sociis
						natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In semper lorem eget tortor pulvinar ultricies.
					</p>
				</div>

				<div class="clearfix"></div>
				<div class="mid_slider">
					<!-- banner -->
					<div id="myCarousel" class="carousel slide" data-ride="carousel">
						<!-- Indicators -->
						<ol class="carousel-indicators">
							<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
							<li data-target="#myCarousel" data-slide-to="1" class=""></li>
							<li data-target="#myCarousel" data-slide-to="2" class=""></li>
							<li data-target="#myCarousel" data-slide-to="3" class=""></li>
						</ol>
						<div class="carousel-inner" role="listbox">
							<div class="item active">
								<div class="row">
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal1.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal2.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal3.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal4.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="row">
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal5.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal6.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal2.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal1.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="row">
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal1.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal2.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal3.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal4.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="row">
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal1.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal2.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal3.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 slidering">
										<div class="thumbnail"><img src="images/gal4.jpg" alt="Image" style="max-width:100%;"></div>
									</div>
								</div>
							</div>
						</div>
						<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span class="fa fa-chevron-left" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
						<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span class="fa fa-chevron-right" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>
						<!-- The Modal -->
					</div>
					<!--//banner -->

				</div>
			</div>
		</div>
	</div>
	<!--/services-->
	<div class="work" id="services">
		<div class="container">
			<div class="work-main">
				<div class="work-top">
					<h3>Our Services</h3>
					<p>Lorem ipsum dolor sit amet,vehicula vel sapien et</p>
				</div>
				<div class="work-bottom_w3ls_agile">
					<div class="work-bottom-top">
						<div class="col-md-4">
							<div class="work-bottom-left_agile_w3ls">
								<span class="fa fa-spoon" aria-hidden="true"></span>
								<h4>Fresh Products</h4>
								<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. </p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="work-bottom-left_agile_w3ls">
								<span class="fa fa-apple" aria-hidden="true"></span>
								<h4>Healthy Food</h4>
								<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. </p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="work-bottom-left_agile_w3ls">
								<span class="fa fa-home" aria-hidden="true"></span>
								<h4>Traditional Methods
								</h4>
								<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. </p>
							</div>
						</div>

						<div class="clearfix"></div>
					</div>
					<div class="work-bottom-top">
						<div class="col-md-4">
							<div class="work-bottom-left_agile_w3ls">
								<span class="fa fa-calendar" aria-hidden="true"></span>
								<h4>Advance Booking</h4>
								<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. </p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="work-bottom-left_agile_w3ls">
								<span class="fa fa-smile-o" aria-hidden="true"></span>
								<h4>Best Chefs</h4>
								<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. </p>
							</div>

						</div>
						<div class="col-md-4">
							<div class="work-bottom-left_agile_w3ls">
								<span class="fa fa-child" aria-hidden="true"></span>
								<h4>150 Tables
								</h4>
								<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. </p>
							</div>
						</div>

						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--//services-->
	<!--/about-->
	<div class="about" id="about_one">
		<div class="container">
			<div class="about-main_w3_agileits">
				<div class="col-md-6 about-left">
					<img src="images/chef.jpg" alt="">
				</div>
				<div class="col-md-6 about-right_agileits">
					<h3>For Goof Taste</h3>
					<p>Nulla sodales efficitur consequat. Maecenas mi diam, imperdiet consectetur ultricies nec, convallis sit amet turpis.
						Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
					<a class="active" href="#" data-toggle="modal" data-target="#myModal">Learn more</a>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--//about-->
	<!--/tab_section-->
	<div class="tabs_section" id="menu">
		<div class="container">
			<h5>Special Menu</h5>
			<div id="horizontalTab">
				<ul class="resp-tabs-list">
					<li> BREAKFAST</li>
					<li> LUNCH</li>
					<li> TO DAY SPECIALS</li>
					<li> DRINKS</li>
				</ul>
				<div class="resp-tabs-container">

					<div class="tab1">
						<div class="recipe-grid">
							<div class="col-md-6 menu-grids">
								<div class="menu-text_wthree">

									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal1.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$ 50</h4>
									</div>
									<div class="clearfix"> </div>
								</div>

								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal2.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$25</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal3.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>

									<div class="menu-text-right">
										<h4>$30</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
							<div class="col-md-6 menu-grids">
								<div class="menu-text_wthree">

									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal4.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$ 50</h4>
									</div>
									<div class="clearfix"> </div>
								</div>

								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal5.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>

									<div class="menu-text-right">
										<h4>$25</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal6.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$30</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
							<div class="clearfix"> </div>
						</div>

						<div class="clearfix"></div>
					</div>

					<div class="tab2">
						<div class="recipe-grid">
							<div class="col-md-6 menu-grids">
								<div class="menu-text_wthree">

									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal9.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$ 50</h4>
									</div>
									<div class="clearfix"> </div>
								</div>

								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal7.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$25</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal8.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>

									<div class="menu-text-right">
										<h4>$30</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
							<div class="col-md-6 menu-grids">
								<div class="menu-text_wthree">

									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal7.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$ 50</h4>
									</div>
									<div class="clearfix"> </div>
								</div>

								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal8.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>

									<div class="menu-text-right">
										<h4>$25</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal9.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$30</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
							<div class="clearfix"> </div>
						</div>

						<div class="clearfix"></div>

					</div>
					<div class="tab3">
						<div class="recipe-grid">
							<div class="col-md-6 menu-grids">
								<div class="menu-text_wthree">

									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal1.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$ 50</h4>
									</div>
									<div class="clearfix"> </div>
								</div>

								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal2.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$25</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal3.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>

									<div class="menu-text-right">
										<h4>$30</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
							<div class="col-md-6 menu-grids">
								<div class="menu-text_wthree">

									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal4.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$ 50</h4>
									</div>
									<div class="clearfix"> </div>
								</div>

								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal5.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>

									<div class="menu-text-right">
										<h4>$25</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="menu-text_wthree">
									<div class="menu-text-left">
										<div class="rep-img">
											<img src="images/gal6.jpg" alt=" " class="img-responsive">
										</div>
										<div class="rep-text">
											<h4>Lorem ipsum dolor............</h4>
											<h6>with wild mushrooms and asparagus</h6>
										</div>

										<div class="clearfix"> </div>
									</div>
									<div class="menu-text-right">
										<h4>$30</h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
							<div class="clearfix"> </div>
						</div>

						<div class="clearfix"></div>
					</div>
					<div class="tab4">

						<div class="col-md-6 menu-grids">
							<div class="menu-text_wthree">

								<div class="menu-text-left">
									<div class="rep-img">
										<img src="images/gal12.jpg" alt=" " class="img-responsive">
									</div>
									<div class="rep-text">
										<h4>Lorem ipsum dolor............</h4>
										<h6>Itaque earum rerum hic tenetur </h6>
									</div>

									<div class="clearfix"> </div>
								</div>
								<div class="menu-text-right">
									<h4>$ 50</h4>
								</div>
								<div class="clearfix"> </div>
							</div>

							<div class="menu-text_wthree">
								<div class="menu-text-left">
									<div class="rep-img">
										<img src="images/gal10.jpg" alt=" " class="img-responsive">
									</div>
									<div class="rep-text">
										<h4>Lorem ipsum dolor............</h4>
										<h6>Itaque earum rerum hic tenetur </h6>
									</div>

									<div class="clearfix"> </div>
								</div>
								<div class="menu-text-right">
									<h4>$25</h4>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="menu-text_wthree">
								<div class="menu-text-left">
									<div class="rep-img">
										<img src="images/gal11.jpg" alt=" " class="img-responsive">
									</div>
									<div class="rep-text">
										<h4>Lorem ipsum dolor............</h4>
										<h6>Itaque earum rerum hic tenetur </h6>
									</div>

									<div class="clearfix"> </div>
								</div>

								<div class="menu-text-right">
									<h4>$30</h4>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
						<div class="col-md-6 menu-grids">
							<div class="menu-text_wthree">

								<div class="menu-text-left">
									<div class="rep-img">
										<img src="images/gal10.jpg" alt=" " class="img-responsive">
									</div>
									<div class="rep-text">
										<h4>Lorem ipsum dolor............</h4>
										<h6>Itaque earum rerum hic tenetur </h6>
									</div>

									<div class="clearfix"> </div>
								</div>
								<div class="menu-text-right">
									<h4>$ 50</h4>
								</div>
								<div class="clearfix"> </div>
							</div>

							<div class="menu-text_wthree">
								<div class="menu-text-left">
									<div class="rep-img">
										<img src="images/gal11.jpg" alt=" " class="img-responsive">
									</div>
									<div class="rep-text">
										<h4>Lorem ipsum dolor............</h4>
										<h6>Itaque earum rerum hic tenetur </h6>
									</div>

									<div class="clearfix"> </div>
								</div>

								<div class="menu-text-right">
									<h4>$25</h4>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="menu-text_wthree">
								<div class="menu-text-left">
									<div class="rep-img">
										<img src="images/gal13.jpg" alt=" " class="img-responsive">
									</div>
									<div class="rep-text">
										<h4>Lorem ipsum dolor............</h4>
										<h6>Itaque earum rerum hic tenetur </h6>
									</div>

									<div class="clearfix"> </div>
								</div>
								<div class="menu-text-right">
									<h4>$30</h4>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>


					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<!-- /tabs -->
	<!--//tab_section-->
	<!--/services-->
	<div class="choose">
		<div class="container">
			<div class="choose-main">
				<div class="col-md-5 choose-left">
					<h2>SPECIAL SERVICES</h2>
				</div>
				<div class="col-md-7 choose-right">
					<div class="col-md-6 choose-right-top">
						<h4>Best Chef</h4>
						<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. Morbi vulputate tempor
							nisl nec tristique.</p>
					</div>
					<div class="col-md-6 choose-right-top">
						<h4>150 Tables</h4>
						<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. Morbi vulputate tempor
							nisl nec tristique.</p>
					</div>
					<div class="clearfix"></div>
					<div class="col-md-6 choose-right-top">
						<h4>Card Payment</h4>
						<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. Morbi vulputate tempor
							nisl nec tristique. </p>
					</div>
					<div class="col-md-6 choose-right-top">
						<h4>Special Offers</h4>
						<p>Duis sit amet posuere justo, sit amet finibus urna. Aenean elementum diam nec laoreet sodales. Morbi vulputate tempor
							nisl nec tristique.</p>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--//services-->
	<!--/gallery-->
	<div class="gallery" id="gallery">
		<div class="container">
			<div class="gallery-main">
				<div class="gallery-top">
					<div class="gallery-top-img portfolio-grids">
						<a href="images/gal6.jpg" class="b-link-stripe b-animate-go lightninBox" data-lb-group="1">
									<img src="images/gal6.jpg" class="img-responsive" alt="" />
									<div class="p-mask">
										<h4><span>Heading here</span></h4>
									</div>
								</a>

					</div>

					<div class="gallery-top-img portfolio-grids">
						<a href="images/gal5.jpg" class="b-link-stripe b-animate-go lightninBox" data-lb-group="1">
									<img src="images/gal5.jpg" class="img-responsive" alt="" />
									<div class="p-mask">
										<h4><span>Heading here</span></h4>
									</div>
								</a>

					</div>
					<div class="gallery-top-img portfolio-grids">
						<a href="images/gal4jpg" class="b-link-stripe b-animate-go lightninBox" data-lb-group="1">
									<img src="images/gal4.jpg" class="img-responsive" alt="" />
									<div class="p-mask">
										<h4><span>Heading here</span></h4>
									</div>
								</a>

					</div>
					<div class="gallery-top-img portfolio-grids">
						<a href="images/gal3.jpg" class="b-link-stripe b-animate-go lightninBox" data-lb-group="1">
									<img src="images/gal3.jpg" class="img-responsive" alt="" />
									<div class="p-mask">
										<h4><span>Heading here</span></h4>
									</div>
								</a>

					</div>
					<div class="gallery-top-img portfolio-grids">
						<a href="images/gal3.jpg" class="b-link-stripe b-animate-go lightninBox" data-lb-group="1">
									<img src="images/gal3.jpg" class="img-responsive" alt="" />
									<div class="p-mask">
										<h4><span>Heading here</span></h4>
									</div>
								</a>

					</div>
					<div class="gallery-top-img portfolio-grids">
						<a href="images/gal1.jpg" class="b-link-stripe b-animate-go lightninBox" data-lb-group="1">
									<img src="images/gal1.jpg" class="img-responsive" alt="" />
									<div class="p-mask">
										<h4><span>Heading here</span></h4>
									</div>
								</a>

					</div>
					<div class="gallery-top-img">
						<h3>OUR SPECIALS</h3>
						<span> </span>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="gallery-bottom">
					<div class="col-md-6 gallery-bottom-text">
						<p>Etiam faucibus viverra libero vel efficitur. Ut semper nisl ut laoreet ultrices. Maecenas dictum arcu purus, sit amet
							volutpat purus viverra sit amet. Quisque lacinia quam sed tortor interdum, malesuada congue nunc ornare. Cum sociis
							natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In semper lorem eget tortor pulvinar ultricies.</p>
					</div>
					<div class="col-md-6 gallery-bottom-text">
						<p>Etiam faucibus viverra libero vel efficitur. Ut semper nisl ut laoreet ultrices. Maecenas dictum arcu purus, sit amet
							volutpat purus viverra sit amet. Quisque lacinia quam sed tortor interdum, malesuada congue nunc ornare. Cum sociis
							natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In semper lorem eget tortor pulvinar ultricies.</p>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<!--//gallery-->
	<div class="reservation" id="book">
		<div class="book-form">
			<h4>Prearrange a Table.</h4>
			<form action="#" method="post">
				<div class="col-md-4 form-time">
					<label><i class="fa fa-clock-o" aria-hidden="true"></i></label>
					<input type="text" id="timepicker" name="Time" placeholder="Time" class="timepicker form-control hasWickedpicker" value="Time"
					    onkeypress="return false;" required="">
				</div>
				<div class="col-md-4 form-date">
					<label><i class="fa fa-calendar" aria-hidden="true"></i> </label>
					<input id="datepicker1" name="Text" type="text" value="mm/dd/yyyy" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}"
					    required="">
				</div>
				<div class="col-md-4 form-left">
					<label><i class="fa fa-users" aria-hidden="true"></i></label>
					<select class="form-control">
								<option>No.of People</option>
								<option>1 Person</option>
								<option>2 People</option>
								<option>3 People</option>
								<option>4 People</option>
								<option>5 People</option>
								<option>More</option>
							</select>
				</div>
				<div class="clearfix"> </div>
				<div class="col-md-3 form-left">
					<ul>
						<li><i class="fa fa-check-square-o" aria-hidden="true"></i>Over 10,000 restaurants Worldwide</li>
						<li><i class="fa fa-check-square-o" aria-hidden="true"></i>No booking fees</li>
					</ul>
				</div>
				<div class="col-md-3 form-left-submit">
					<input type="submit" value="Book a table">
				</div>
				<div class="clearfix"> </div>
			</form>

		</div>

	</div>
	<!--/customer-->
	<div class="comments" id="client">
		<div class="container">
			<div class="comments-main">
				<div class="comments-head">
					<h3>Comments from our customers</h3>
					<p>Lorem ipsum dolor sit amet,vehicula vel sapien et</p>
				</div>
				<div class="comments-top">
					<div class="col-md-4 comments-bottom">
						<div class="comments-left">
							<span class="fa fa-quote-right"></span>
						</div>
						<div class="comments-right">
							<h3>Paul Demichev</h3>
							<p class="para1">Client,Some Company</p>
							<p class="para2">Nulla sodales efficitur consequat. Maecenas mi diam, imperdiet consectetur ultricies nec, convallis sit amet turpis.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-4 comments-bottom">
						<div class="comments-left">
							<span class="fa fa-quote-right"></span>
						</div>
						<div class="comments-right">
							<h3>Oleg Topanic</h3>
							<p class="para1">Client,Some Company</p>
							<p class="para2">Nulla sodales efficitur consequat. Maecenas mi diam, imperdiet consectetur ultricies nec, convallis sit amet turpis.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-4 comments-bottom">
						<div class="comments-left">
							<span class="fa fa-quote-right"></span>
						</div>
						<div class="comments-right">
							<h3>Julia Usina</h3>
							<p class="para1">Client,Some Company</p>
							<p class="para2">Nulla sodales efficitur consequat. Maecenas mi diam, imperdiet consectetur ultricies nec, convallis sit amet turpis.

							</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
					<div class="col-md-4 comments-bottom">
						<div class="comments-left">
							<span class="fa fa-quote-right"></span>
						</div>
						<div class="comments-right">
							<h3>Serdyuk Elena</h3>
							<p class="para1">Client,Some Company</p>
							<p class="para2">Nulla sodales efficitur consequat. Maecenas mi diam, imperdiet consectetur ultricies nec, convallis sit amet turpis.
							</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-4 comments-bottom">
						<div class="comments-left">
							<span class="fa fa-quote-right"></span>
						</div>
						<div class="comments-right">
							<h3>Kulikov Vlad</h3>
							<p class="para1">Client,Some Company</p>
							<p class="para2">Nulla sodales efficitur consequat. Maecenas mi diam, imperdiet consectetur ultricies nec, convallis sit amet turpis.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-4 comments-bottom">
						<div class="comments-left">
							<span class="fa fa-quote-right"></span>
						</div>
						<div class="comments-right">
							<h3>Andrey Tikhonov</h3>
							<p class="para1">Client,Some Company</p>
							<p class="para2">Nulla sodales efficitur consequat. Maecenas mi diam, imperdiet consectetur ultricies nec, convallis sit amet turpis.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<?php $__env->startPush('scripts'); ?>
	<script>
	$(function() {

$(".input input").focus(function() {

   $(this).parent(".input").each(function() {
	  $("label", this).css({
		 "line-height": "18px",
		 "font-size": "18px",
		 "font-weight": "100",
		 "top": "0px"
	  })
	  $(".spin", this).css({
		 "width": "100%"
	  })
   });
}).blur(function() {
   $(".spin").css({
	  "width": "0px"
   })
   if ($(this).val() == "") {
	  $(this).parent(".input").each(function() {
		 $("label", this).css({
			"line-height": "60px",
			"font-size": "24px",
			"font-weight": "300",
			"top": "10px"
		 })
	  });

   }
});

$(".button").click(function(e) {
   var pX = e.pageX,
	  pY = e.pageY,
	  oX = parseInt($(this).offset().left),
	  oY = parseInt($(this).offset().top);

   $(this).append('<span class="click-efect x-' + oX + ' y-' + oY + '" style="margin-left:' + (pX - oX) + 'px;margin-top:' + (pY - oY) + 'px;"></span>')
   $('.x-' + oX + '.y-' + oY + '').animate({
	  "width": "500px",
	  "height": "500px",
	  "top": "-250px",
	  "left": "-250px",

   }, 600);
   $("button", this).addClass('active');
})

$(".alt-2").click(function() {
   if (!$(this).hasClass('material-button')) {
	  $(".shape").css({
		 "width": "100%",
		 "height": "100%",
		 "transform": "rotate(0deg)"
	  })

	  setTimeout(function() {
		 $(".overbox").css({
			"overflow": "initial"
		 })
	  }, 600)

	  $(this).animate({
		 "width": "75px",
		 "height": "75px"
	  }, 500, function() {
		 $(".box").removeClass("back");

		 $(this).removeClass('active')
	  });

	  $(".overbox .title").fadeOut(300);
	  $(".overbox .input").fadeOut(300);
	  $(".overbox .button").fadeOut(300);

	  $(".alt-2").addClass('material-buton');
   }

})

$(".material-button").click(function() {

   if ($(this).hasClass('material-button')) {
	  setTimeout(function() {
		 $(".overbox").css({
			"overflow": "hidden"
		 })
		 $(".box").addClass("back");
	  }, 200)
	  $(this).addClass('active').animate({
		 "width": "700px",
		 "height": "700px"
	  });

	  setTimeout(function() {
		 $(".shape").css({
			"width": "60%",
			"height": "50%",
			"transform": "rotate(45deg)"
		 })

		 $(".overbox .title").fadeIn(300);
		 $(".overbox .input").fadeIn(300);
		 $(".overbox .button").fadeIn(300);
	  }, 700)

	  $(this).removeClass('material-button');

   }

   if ($(".alt-2").hasClass('material-buton')) {
	  $(".alt-2").removeClass('material-buton');
	  $(".alt-2").addClass('material-button');
   }

});

});</script>
	<?php $__env->stopPush(); ?>
	<!--//customer-->
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-site/layouts/page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/project/cuca-table/resources/views/front-site/index.blade.php ENDPATH**/ ?>