<?php $__env->startSection("page_name"); ?> Dashboard <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Table -->
    <div class="container-fluid mt--7">
      
    <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
                <!-- alert
            <div class="alert alert-success" role="alert">
                <strong>Success!</strong> This is a success alert—check it out!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="alert alert-danger" role="alert">
                <strong>Danger!</strong> This is a failed alert—check it out!
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                </button>
            </div> -->
            <!-- //Alert -->
                <div class="row">
                    <div class="col-6">
                    <h3 class="mb-3">Our Restaurant Space</h3>
                    <a href="<?php echo e(route('space.create')); ?>" class="btn btn-primary btn-sm"> Add New Menu</a>
                    </div>
                    <div class="col-6">
                        <form class="navbar-search">
                            <div class="form-group mb-0">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    </div>
                                    <input class="form-control" placeholder="Search" type="text">
                                </div>
                            </div>
                        </form>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success mt-3">
                            <?php echo e($message); ?>

                        </div>
                        <?php elseif($message = Session::get('failed')): ?>
                        <div class="alert alert-danger mt-3">
                            <?php echo e($message); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Pax</th>
                    <th scope="col">Avaibility</th>
                    <th scope="col">Description</th>
                    <th scope="col">Status</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row">
                      <div class="media align-items-center">
                        <a href="#" class="avatar rounded-circle mr-3">
                          <img alt="Image placeholder" src="<?php echo e(url('/images/spaces/'.$dt->image)); ?>">
                        </a>
                        <div class="media-body">
                          <span class="mb-0 text-sm"><?php echo e($dt->name); ?></span>
                        </div>
                      </div>
                    </th>
                    <td>
                    <?php echo e($dt->minimum_pax . " - ". $dt->maximum_pax); ?>

                    </td>
                    <td>
                    <?php echo e($dt->avaibility); ?>

                    </td>
                    <td>
                    <?php echo e($dt->desc); ?>

                    </td>
                    <td>
                      <div class="d-flex align-items-center">
                      <span class="badge badge-dot mr-4">
                        <i class="<?php echo e($dt->status==1?'bg-success':'bg-danger'); ?>"></i> <?php echo e($dt->status==1?"Active":"Deactive"); ?>

                      </span>
                      </div>
                    </td>
                    <td class="text-right">
                      <div class="dropdown">
                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-ellipsis-v"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                          <a class="dropdown-item" href="<?php echo e(route('space.edit',$dt->id)); ?>">Edit Data Space</a>
                          <a class="dropdown-item" href="<?php echo e(route('space.delete',$dt->id)); ?>"><?php echo e($dt->status == 1 ? 'Deactived Space' : 'Actived Space'); ?></a>
                        </div>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="card-footer py-4">
              <nav aria-label="...">
              <?php echo $data->links(); ?>

              </nav>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/project/cuca-table/resources/views/panel/space.blade.php ENDPATH**/ ?>