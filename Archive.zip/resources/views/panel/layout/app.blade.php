@include('panel.components.header')
@yield('content')
@include('panel.components.footer')