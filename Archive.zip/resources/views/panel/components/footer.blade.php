
      <!-- Footer -->
      
    </div>
  </div>
  <!--   Core   -->
  <script src="{{url('/assets/js/plugins/jquery/dist/jquery.min.js')}}"></script>
  <script src="{{url('/assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
  <!--   Optional JS   -->
  <script src="{{url('/assets/js/plugins/chart.js/dist/Chart.min.js')}}"></script>
  <script src="{{url('/assets/js/plugins/chart.js/dist/Chart.extension.js')}}"></script>
  <script src="{{url('/assets/js/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>
  <script src="{{url('/js/jquery.datetimepicker.full.js')}}"></script>
  <!--   Argon JS   -->
  <script src="{{url('/assets/js/argon-dashboard.js')}}"></script>
  <script src="{{url('/assets/js/timepicker.min.js')}}"></script>
  <script src="{{url('/assets/js/moment.js')}}"></script>
  
  @stack('scripts')
</body>

</html>