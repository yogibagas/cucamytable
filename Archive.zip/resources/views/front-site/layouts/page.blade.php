@include('front-site/components/header')
@yield('content')
@include('front-site/components/footer')